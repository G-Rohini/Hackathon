package com.example.covid_diagnoser;

import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.content.CursorLoader;

import com.bumptech.glide.Glide;
import com.example.covid_diagnoser.API.ApiConfig;
import com.example.covid_diagnoser.API.model.ServerResponse;
import com.example.covid_diagnoser.audio.calculators.AudioCalculator;
import com.example.covid_diagnoser.audio.core.Callback;
import com.example.covid_diagnoser.audio.core.Recorder;
import com.example.covid_diagnoser.mail.SendMail;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Response;

import static com.github.mikephil.charting.charts.Chart.LOG_TAG;

public class Symptoms extends AppCompatActivity {

    static float maxTemp = 106;
    static float minTemp = 96;

    String wavPath;


    double count = 0.0;
    Recorder recorder;
    AudioCalculator audioCalculator;
    Handler handler;
    HashMap<Double, Double> data = new HashMap<>();
    Bundle args;
    String advice = "";
    boolean isRecording = false;

    SeekBar breath;
    SeekBar cough;
    EditText feverEt;
    ImageView plusIv, recordCoughBtn;
    ImageView minusIv;
    Switch soreThroat,nasalCongestion,achesAndPains, travel, tirednessSwitch, nauseaSwitch, diarrheaSwitch;
    ImageView beforeIv, recordingIv, doneBtn;
    Button startStopBtn;
    EditText firstNameEt, lastNameEt;
    private MediaRecorder mRecorder = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_symptoms);

        breath = findViewById(R.id.breath);
        cough = findViewById(R.id.cough);
        feverEt = findViewById(R.id.fever_et);
        plusIv = findViewById(R.id.plus_tmp);
        minusIv = findViewById(R.id.minus_tmp);
        nasalCongestion = findViewById(R.id.nasalCongestion);
        soreThroat = findViewById(R.id.soreThroat);
        achesAndPains = findViewById(R.id.achesAndPains);
        travel = findViewById(R.id.travel);
        recordCoughBtn = findViewById(R.id.record_cough_btn);
        firstNameEt = findViewById(R.id.first_name);
        lastNameEt = findViewById(R.id.last_name);
        tirednessSwitch = findViewById(R.id.tiredness);
        nauseaSwitch = findViewById(R.id.nauseaQuestion);
        diarrheaSwitch = findViewById(R.id.diarrheaQuestion);

        wavPath = getFilesDir().getAbsolutePath() + "/tmp1.wav";

        minusIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (feverEt.getText().toString().equals("")) {
                    feverEt.setText("96");
                } else if (Float.parseFloat(feverEt.getText().toString()) <= minTemp) {
                    feverEt.setText("96");
                } else {
                    int val = (int)Float.parseFloat(feverEt.getText().toString());
                    feverEt.setText(String.valueOf(val - 1));
                }
            }
        });

        plusIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (feverEt.getText().toString().equals("")) {
                    feverEt.setText("96");
                } else if (Float.parseFloat(feverEt.getText().toString()) >= maxTemp) {
                    feverEt.setText("106");
                } else {
                    int val = (int)Float.parseFloat(feverEt.getText().toString());
                    feverEt.setText(String.valueOf(val + 1));
                }
            }
        });

        recordCoughBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showVoiceRecordDialog();
            }
        });
    }

    public void calculateProbability(View v) {
        //SeekBar fever = findViewById(R.id.fever);

        DecimalFormat df = new DecimalFormat("0.00");

        int feverValue = 0;
        if (feverEt.getText().toString().equals("")) {
            Toast.makeText(getApplicationContext(), "Please, enter temperature", Toast.LENGTH_LONG).show();
            return;
        }
        feverValue = (int)Float.parseFloat(feverEt.getText().toString());
        if (feverValue < minTemp || feverValue > maxTemp) {
            Toast.makeText(getApplicationContext(), "Please, enter valid temperature", Toast.LENGTH_LONG).show();
            return;
        }
        if (firstNameEt.getText().toString().trim().equals("")) {
            Toast.makeText(getApplicationContext(), "Please, enter your first name", Toast.LENGTH_LONG).show();
            return;
        }
        if (lastNameEt.getText().toString().trim().equals("")) {
            Toast.makeText(getApplicationContext(), "Please, enter your last name", Toast.LENGTH_LONG).show();
            return;
        }
       /* if (data == null || data.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Please, record your coughing sound", Toast.LENGTH_LONG).show();
            return;
        }*/

        int tirednessValue = breath.getProgress();
        int coughValue = cough.getProgress();
        boolean nasalCongestionState = nasalCongestion.isChecked();
        boolean soreThroatState = soreThroat.isChecked();
        boolean achesAndPainsState = achesAndPains.isChecked();
        boolean travelState = travel.isChecked();
        boolean tiredState = tirednessSwitch.isChecked();
        boolean nauseaState = nauseaSwitch.isChecked();
        boolean diarrheaState = diarrheaSwitch.isChecked();

        double val1 = maxTemp - feverValue;
        double val2 = val1 / 10;
        double val3 = val2 * 100;
        double finalFeverValue = 100 - val3;
        double chance = 0.2 * finalFeverValue + 0.2 * tirednessValue
                + 10 * boolToInt(nasalCongestionState) + 10 * boolToInt(soreThroatState) +
                10 * boolToInt(achesAndPainsState)+ 10 * boolToInt(tiredState)+
                10 * boolToInt(nauseaState) + 10 * boolToInt(diarrheaState);// + 10 * boolToInt(travelState)


        if (chance > 75) {
            advice = "High";
        } else if (chance < 75 && chance > 50){
            advice = "Medium";
        } else {
            advice = "Low";
        }

        args = new Bundle();
        args.putString("chances", df.format(chance) + "%");
        args.putString("advice", advice);
        args.putString("name", firstNameEt.getText().toString() + " " + lastNameEt.getText().toString());
        args.putSerializable("data", data);
        //uploadFile(args);
        showAnalysisDialog();
    }

    int boolToInt(Boolean b) {
        return b.compareTo(false);
    }

    private void showVoiceRecordDialog() {

        recorder = new Recorder(getApplicationContext(),callback);
        audioCalculator = new AudioCalculator();
        handler = new Handler(Looper.getMainLooper());
        //wavPath = getExternalCacheDir().getAbsolutePath();
        //wavPath += "/test.wav";

        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.voice_dialog);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        ImageView closeBtn = dialog.findViewById(R.id.close_btn);
        startStopBtn = dialog.findViewById(R.id.record_btn);
        beforeIv = dialog.findViewById(R.id.before_record_iv);
        recordingIv = dialog.findViewById(R.id.recording_iv);
        doneBtn = dialog.findViewById(R.id.done_btn);
        Glide.with(getApplicationContext()).load(R.raw.recording).into(recordingIv);

        startStopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (startStopBtn.getText().toString().equals(getResources().getString(R.string.start_record_txt))) {
                    beforeIv.setVisibility(View.GONE);
                    recordingIv.setVisibility(View.VISIBLE);
                    startStopBtn.setText(getResources().getString(R.string.stop_record_txt));
                    if (data != null) data.clear();
                    //startRecording();
                    isRecording = true;
                    recorder.start();
                } else {
                    doneBtn.setVisibility(View.VISIBLE);
                    beforeIv.setVisibility(View.VISIBLE);
                    recordingIv.setVisibility(View.GONE);
                    startStopBtn.setText(getResources().getString(R.string.start_record_txt));
                    recorder.stop();
                    isRecording = false;
                    //stopRecording();


                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    count = 0.0;
                }
            }
        });
        doneBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    recorder.stop();
                } catch (Exception e) {
                }
                dialog.dismiss();
            }
        });


        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    recorder.stop();
                } catch (Exception e) {
                }
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private Callback callback = new Callback() {
        @Override
        public void onBufferAvailable(byte[] buffer) {

            audioCalculator.setBytes(buffer);
            int amplitude = audioCalculator.getAmplitude();
            double decibel = audioCalculator.getDecibel();
            double frequency = audioCalculator.getFrequency();
            data.put(count, (double) frequency);
            final String amp = String.valueOf(amplitude + " Amp");
            final String db = String.valueOf(decibel + " db");
            final String hz = String.valueOf(frequency + " Hz");
            count++;
        }
    };

    private void startRecording() {
        mRecorder = new MediaRecorder();
        mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mRecorder.setOutputFormat(MediaRecorder.OutputFormat.RAW_AMR);
        mRecorder.setOutputFile(wavPath);
        mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);

        try {
            mRecorder.prepare();
        } catch (IOException e) {
            Log.e(LOG_TAG, "prepare() failed");
        }

        mRecorder.start();
    }

    private void stopRecording() {
        mRecorder.stop();
        mRecorder.release();
        mRecorder = null;
    }

    private void uploadFile(Bundle args) {
        // Map is used to multipart the file using okhttp3.RequestBody
        File file = new File(wavPath);

        // Parsing any Media type file
        RequestBody requestBody = RequestBody.create(MediaType.parse("*/*"), file);
        MultipartBody.Part fileToUpload = MultipartBody.Part.createFormData("file", file.getName(), requestBody);
        RequestBody filename = RequestBody.create(MediaType.parse("text/plain"), file.getName());

        ApiConfig apiInterface = ApiConfig.retrofit.create(ApiConfig.class);
        Call<ServerResponse> call = apiInterface.uploadFile(fileToUpload, filename);
        call.enqueue(new retrofit2.Callback<ServerResponse>() {
            @Override
            public void onResponse(Call<ServerResponse> call, Response<ServerResponse> response) {
                ServerResponse serverResponse = (ServerResponse) response.body();
                if (serverResponse != null) {
                    if (serverResponse.getSuccess()) {
                        Toast.makeText(getApplicationContext(), serverResponse.getMessage(), Toast.LENGTH_SHORT).show();
                        Intent resultIntent = new Intent(getApplicationContext(), ResultActivity.class);
                        resultIntent.putExtras(args);
                        startActivity(resultIntent);
                    } else {
                        Toast.makeText(getApplicationContext(), serverResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    assert serverResponse != null;
                    Log.v("Response", serverResponse.toString());
                }
            }

            @Override
            public void onFailure(Call call, Throwable t) {
            }
        });
    }

    private String getRealPathFromURI(Uri contentUri) {
        String[] proj = {MediaStore.Images.Media.DATA};
        CursorLoader loader = new CursorLoader(this, contentUri, proj, null, null, null);
        Cursor cursor = loader.loadInBackground();
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String result = cursor.getString(column_index);
        cursor.close();
        return result;
    }

    private void showAnalysisDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.analysis_dialog);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        Button onBtn = dialog.findViewById(R.id.ok_btn);
        ImageView closeBtn = dialog.findViewById(R.id.close_btn);
        onBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendEmail();
                dialog.dismiss();
                navigateToResult();
            }
        });
        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    recorder.stop();
                } catch (Exception e) {
                }
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void showEndingDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.ending_dialog);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        Button yesBtn = dialog.findViewById(R.id.yes_btn);
        Button noBtn = dialog.findViewById(R.id.no_btn);
        Button mayBeBtn = dialog.findViewById(R.id.may_be_btn);

        yesBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();

            }
        });

        noBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
                //navigateToResult();
            }
        });

        mayBeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
                //navigateToResult();
            }
        });
        dialog.show();
    }

    private void navigateToResult() {
        Intent resultIntent = new Intent(this, ResultActivity.class);
        resultIntent.putExtras(args);
        startActivity(resultIntent);
    }

    private void sendEmail() {
        String email = "drcovid19detect@gmail.com";
        String subject = "Covid 19 Diagnosis Request";
        String message = "Hello, \nUser name : " + firstNameEt.getText().toString()+" "+lastNameEt.getText().toString() +
                "\nApp result : "+ advice +" "+ "risk \n\nThank you.";
        SendMail sm = new SendMail(this, email, subject, message, args);
        sm.execute();
    }

}

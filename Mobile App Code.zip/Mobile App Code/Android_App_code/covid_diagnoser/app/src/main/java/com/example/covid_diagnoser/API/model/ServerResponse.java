package com.example.covid_diagnoser.API.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ServerResponse {
    @SerializedName("success")
    @Expose
    boolean success;
    @SerializedName("message")
    @Expose
    String message;
    public String getMessage() {
        return message;
    }
    public boolean getSuccess() {
        return success;
    }
}

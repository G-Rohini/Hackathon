from flask import Flask, jsonify
from flask import request, redirect
from werkzeug.utils import secure_filename
from keyword_spotting_service import *

app = Flask(__name__)
@app.route('/')
def index():
 return "Hello, World!"

users= [
 {
 'id': 1,
 'name': 'john'
 }
]

@app.route('/users', methods=['GET'])
def get_users():
 return jsonify({'users': users})


@app.route('/upload-file', methods=['GET', 'POST'])
def upload_file():
   if request.method == 'POST':
       if 'file' not in request.files:
           print('No file attached in request')
           return redirect(request.url)
       file = request.files['file']
       if file.filename == '':
           print('No file selected')
           return redirect(request.url)
       if file and allowed_file(file.filename):
           filename = secure_filename(file.filename)
           print(filename)
           file.save(filename)
           kss = Keyword_Spotting_Service()
           keyword = kss.predict(filename)
           return "{'success':true, 'message':'File uploaded'}" + keyword
   kss = Keyword_Spotting_Service()
   keyword = kss.predict("test/tmp.wav")
   return keyword



ALLOWED_EXTENSIONS = {'wav'}
def allowed_file(filename):
   return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

if __name__ == '__main__':
 app.run(debug=True)

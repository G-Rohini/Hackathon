package com.example.covid_diagnoser;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Html;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.covid_diagnoser.voice.CoughingChecker;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ResultActivity extends AppCompatActivity {
    CardView cardView;
    Button checkCoughingBtn;
    LineChart lineChart;
    HashMap<Double, Double> data = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        cardView = findViewById(R.id.card_view);
        checkCoughingBtn = findViewById(R.id.check_coughing_btn);
        lineChart = findViewById(R.id.line_chart);

        TextView chancesTv = findViewById(R.id.chances_tv);
        TextView adviceTv = findViewById(R.id.advice_tv);
        TextView nameTv = findViewById(R.id.name_tv);

        if(getIntent().getStringExtra("chances")!=null){
            chancesTv.setText(getIntent().getStringExtra("chances"));
        }
        if(getIntent().getStringExtra("name")!=null){
            nameTv.setText(getIntent().getStringExtra("name"));
        }
        if(getIntent().getSerializableExtra("data")!=null){
            try{
                data = (HashMap<Double, Double>) getIntent().getSerializableExtra("data");
            }catch (Exception e){
                Log.e("Error", e.getMessage());
            }
        }
        if(getIntent().getStringExtra("advice")!=null){
            adviceTv.setText(getIntent().getStringExtra("advice"));
            if(adviceTv.getText().toString().equals("High")){
                String st = "You are <u>at</u> <u>Corona Virus risk.</u><br>Please visit a Doctor immediately.";
                SpannableString content = new SpannableString(st);
                content.setSpan(new UnderlineSpan(), 8, 29, 0);
                adviceTv.setText(Html.fromHtml(st));
                adviceTv.setTextColor(getResources().getColor(R.color.red));
            }else if(adviceTv.getText().toString().equals("Medium")){
                String st = "You may <u>not</u> be at <u>Corona Virus risk.</u><br>Please <u>watch</u> if you <u>have</u> <u>fever</u>, <u>cough</u>, <u>shortness of breath</u> or <u>other symptoms</u> in <u>next few days.</u><br>Please follow Covid-19 precautions and stay safe.";
                adviceTv.setText(Html.fromHtml(st));
                adviceTv.setTextColor(getResources().getColor(R.color.Orange));
            }else if (adviceTv.getText().toString().equals("Low")){
                String st = "You may <u>not</u> be at <u>Corona Virus risk.</u><br>Please follow Covid-19 precautions and stay safe.";
                adviceTv.setText(Html.fromHtml(st));
                adviceTv.setTextColor(getResources().getColor(R.color.green));
            }
        }

        checkCoughingBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ResultActivity.this, GraphActivity.class));
            }
        });
        setLineChart();
    }

    private void setLineChart() {
        XAxis xAxis = lineChart.getXAxis();
        xAxis.setDrawGridLines(false);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);

        YAxis rightAxis = lineChart.getAxisRight();
        rightAxis.setDrawAxisLine(false);
        rightAxis.setTextColor(Color.WHITE);
        rightAxis.setDrawGridLines(false);

        YAxis leftAxis = lineChart.getAxisLeft();

        // leftAxis.setTextColor(ColorTemplate.getHoloBlue());
        //leftAxis.setAxisMaxValue(200f);
        leftAxis.setDrawGridLines(false);

        List<Double> list_ = new ArrayList<>();
        ArrayList<Entry> listData = new ArrayList<Entry>();
        if (!data.isEmpty()) {
            for (Map.Entry<Double, Double> entry : data.entrySet()) {
                list_.add(entry.getValue());
                listData.add(new Entry(entry.getKey().floatValue(), entry.getValue().floatValue()));
            }
        }
        //String maxVal = Collections.max(list_).toString();
        LineDataSet dataSet = new LineDataSet(listData, "Amplitude");
        dataSet.setHighlightEnabled(true);
        dataSet.setLineWidth(2);
        dataSet.setColor(R.color.black);
        dataSet.setCircleColor(R.color.green);
        LineData lineData = new LineData(dataSet);
        lineData.setDrawValues(false);

        lineChart.getDescription().setText("Hz");
        lineChart.setData(lineData);
        lineChart.invalidate();
        lineChart.getData().notifyDataChanged();
        lineChart.notifyDataSetChanged();
    }

}

package com.example.covid_diagnoser.audio.core;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Process;
import android.util.Log;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Recorder {

    private int audioSource = MediaRecorder.AudioSource.DEFAULT;
    private int channelConfig = AudioFormat.CHANNEL_IN_MONO;
    private int audioEncoding = AudioFormat.ENCODING_PCM_16BIT;
    private int sampleRate = 44100;
    private Thread thread;
    private Callback callback;
    private Context context;
    String wavPath;
    boolean isRecording = false;
    private Thread recordingThread = null;
    AudioRecord recorder;
    int minBufferSize ;

    public Recorder() {
    }

    public Recorder(Context context,Callback callback) {
        this.callback = callback;
        this.context = context;
        wavPath = context.getFilesDir().getAbsolutePath() + "/tmp1.wav";
        minBufferSize =  AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioEncoding);

    }

    public void setCallback(Callback callback) {
        this.callback = callback;
    }

    public void start() {
        if (thread != null) return;
        thread = new Thread(new Runnable() {
            @Override
            public void run() {
                Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
                Log.d("Audio"," Start audio thread");

                recorder = new AudioRecord(audioSource, sampleRate, channelConfig, audioEncoding, minBufferSize);
                if (recorder.getState() == AudioRecord.STATE_UNINITIALIZED) {
                    Log.d("Audio"," State un initialize");
                    Thread.currentThread().interrupt();
                    return;
                } else {
                    Log.i(Recorder.class.getSimpleName(), "Started.");
                    //callback.onStart();
                }
                byte[] buffer = new byte[minBufferSize];
                recorder.startRecording();
                Log.d("Audio"," Start recording");
                isRecording = true;
                recordingThread = new Thread(new Runnable() {

                    public void run() {
                        Log.d("Audio","Start saving");
                        writeAudioDataToFile();

                    }
                }, "AudioRecorder Thread");
                while (thread != null && !thread.isInterrupted() && recorder.read(buffer, 0, minBufferSize) > 0) {
                    callback.onBufferAvailable(buffer);
                    Log.d("Audio"," Buffering ");
                }
                Log.d("Audio"," Stop recording ");
                isRecording = false;
                recorder.stop();
                recorder.release();
            }
        }, Recorder.class.getName());
        thread.start();
    }

    public void stop() {
        if (thread != null) {
            thread.interrupt();
            thread = null;
        }
    }

    private void writeAudioDataToFile() {
        // Write the output audio in byte
        //AudioRecord recorder = null;
        int BufferElements2Rec = 1024;int BytesPerElement = 2;
        short sData[] = new short[BufferElements2Rec];

        FileOutputStream os = null;
        try {
            os = new FileOutputStream(wavPath);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        Log.d("Audio","Start saving to file");
        while (isRecording) {
            // gets the voice output from microphone to byte format

            recorder.read(sData, 0, BufferElements2Rec);
            System.out.println("Short wirting to file" + sData.toString());
            try {
                // // writes the data to file from buffer
                // // stores the voice buffer

                byte bData[] = short2byte(sData);

                os.write(bData, 0, BufferElements2Rec * BytesPerElement);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        try {
            os.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private byte[] short2byte(short[] sData) {
        int shortArrsize = sData.length;
        byte[] bytes = new byte[shortArrsize * 2];

        for (int i = 0; i < shortArrsize; i++) {
            bytes[i * 2] = (byte) (sData[i] & 0x00FF);
            bytes[(i * 2) + 1] = (byte) (sData[i] >> 8);
            sData[i] = 0;
        }
        return bytes;

    }

}

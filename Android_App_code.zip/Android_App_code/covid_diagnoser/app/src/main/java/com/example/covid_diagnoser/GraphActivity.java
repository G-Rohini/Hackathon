package com.example.covid_diagnoser;

import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.covid_diagnoser.audio.calculators.AudioCalculator;
import com.example.covid_diagnoser.audio.core.Callback;
import com.example.covid_diagnoser.audio.core.Recorder;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class GraphActivity extends AppCompatActivity {

    private Recorder recorder;
    private AudioCalculator audioCalculator;
    private Handler handler;

    private TextView textAmplitude, maxVal;
    private TextView textDecibel;
    private TextView textFrequency;
    Button startStopBtn;
    LineChart lineChart;
    double count = 0.0;
    LinkedHashMap<Double, Double> data = new LinkedHashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);

        recorder = new Recorder(getApplicationContext(),callback);
        audioCalculator = new AudioCalculator();
        handler = new Handler(Looper.getMainLooper());

        textAmplitude = (TextView) findViewById(R.id.textAmplitude);
        textDecibel = (TextView) findViewById(R.id.textDecibel);
        textFrequency = (TextView) findViewById(R.id.textFrequency);
        maxVal = (TextView) findViewById(R.id.max_val);
        startStopBtn = findViewById(R.id.record_btn);
        lineChart = findViewById(R.id.line_chart);

        startStopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (startStopBtn.getText().toString().equals(getResources().getString(R.string.start_record_txt))) {
                    if(data!=null) data.clear();
                    startStopBtn.setText(getResources().getString(R.string.stop_record_txt));
                    recorder.start();
                } else {
                    recorder.stop();
                    startStopBtn.setText(getResources().getString(R.string.start_record_txt));
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    new Handler().post(new Runnable() {
                        @Override
                        public void run() {
                            setLineChart();
                        }
                    });
                    count = 0.0;
                }
            }
        });
    }

    private void setLineChart() {
        XAxis xAxis = lineChart.getXAxis();
        xAxis.setDrawGridLines(false);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);

        YAxis rightAxis = lineChart.getAxisRight();
        rightAxis.setDrawAxisLine(false);
        rightAxis.setTextColor(Color.WHITE);
        rightAxis.setDrawGridLines(false);

        YAxis leftAxis = lineChart.getAxisLeft();

       // leftAxis.setTextColor(ColorTemplate.getHoloBlue());
        //leftAxis.setAxisMaxValue(200f);
        leftAxis.setDrawGridLines(false);

        List<Double> list_ = new ArrayList<>();
        ArrayList<Entry> listData = new ArrayList<Entry>();
        if (!data.isEmpty()) {
            for (Map.Entry<Double, Double> entry : data.entrySet()) {
                list_.add(entry.getValue());
                listData.add(new Entry(entry.getKey().floatValue(), entry.getValue().floatValue()));
            }
        }
        maxVal.setText(Collections.max(list_).toString());
        LineDataSet dataSet = new LineDataSet(listData, "Amplitude");
        dataSet.setHighlightEnabled(true);
        dataSet.setLineWidth(2);
        dataSet.setColor(R.color.black);
        dataSet.setCircleColor(R.color.green);
        LineData lineData = new LineData(dataSet);
        lineData.setDrawValues(false);

        lineChart.getDescription().setText("Hz");
        lineChart.setData(lineData);
        lineChart.invalidate();
        lineChart.getData().notifyDataChanged();
        lineChart.notifyDataSetChanged();
    }

    private Callback callback = new Callback() {

        @Override
        public void onBufferAvailable(byte[] buffer) {

            audioCalculator.setBytes(buffer);
            int amplitude = audioCalculator.getAmplitude();
            double decibel = audioCalculator.getDecibel();
            double frequency = audioCalculator.getFrequency();
            data.put(count, (double)frequency);
            final String amp = String.valueOf(amplitude + " Amp");
            final String db = String.valueOf(decibel + " db");
            final String hz = String.valueOf(frequency + " Hz");
            count ++;
            handler.post(new Runnable() {
                @Override
                public void run() {
                    textAmplitude.setText(amp);
                    textDecibel.setText(db);
                    textFrequency.setText(hz);
                }
            });
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        // recorder.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        recorder.stop();
    }
}

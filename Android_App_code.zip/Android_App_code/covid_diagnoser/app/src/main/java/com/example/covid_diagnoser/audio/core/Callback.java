package com.example.covid_diagnoser.audio.core;

public interface Callback {
    void onBufferAvailable(byte[] buffer);
}